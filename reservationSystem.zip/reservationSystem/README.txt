Eduard Marcencov
Theater Seating Challenge 

Instructions:

1. Open folder in terminal.
2. Compile file by using "java Cinema.java".
3  Run the code with "java Cinema" + a system argument, or path, to the input file you intend to use.
4. The movie theater chart will then print out and show a layout of seats marked either with an "R" for reserved, or an "." for empty. As promised, there is a 3 seat buffer between each sequence of filled seats. 

Assumptions:

1. User is familiar with declaring a path to the input file, and can compile/run java programs with system arguments. 

2. The row limit currently sits at 10 rows, anything over that will throw an outOfRange exception. More would have been implemented, but I was unable to do so due to time constraints.

3. The user will know how to enter the path of the input file as a system argument following their run command of the java program.

4. All reservations are 20 seats or less. 

5. Any reservations that overfill the seat capacity of the theater will simply be ignored for the time being. 
 


