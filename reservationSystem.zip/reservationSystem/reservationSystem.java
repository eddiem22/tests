import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class reservationSystem {
    public static final String[] rowMap = {"Row 1:","Row 2:","Row 3:","Row 4:","Row 5:","Row 6:","Row 7:","Row 8:","Row 9:","Row 10:"};
    public static final int rows = 10; //rows
    public static final int seats = 20; //seats
    public static final int safetySpace = 3; //safety buffer (3 seats)

    public static char[][] seatingLayout; //initialize layout for seats
    public static String output = ""; //string for concactinating results

     ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    private static void parseLine(String line) 
    {//start filling spots, with priority from the back. starts from left to right of each row. if the row is out of spots, go to next row in front.

        // Get reservation number and reservation size from line
        int reservationNumber = Integer.parseInt(line.split(" ")[0].substring(1)); //first part of string will hold res. number
        int reservationSize = Integer.parseInt(line.split(" ")[1]); //second part of string will hold res. size

        // Call the fitting method for each row passing in reservation size.
        int rowIndex = 0;
        while (!canFitRes(reservationSize, rowIndex, reservationNumber) && rowIndex < rows) rowIndex++;
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //returns the possibility for a spot if reservation can fit in row
    private static boolean canFitRes(int reservationSize, int rowIndex, int reservationNumber)
    {
        int left = 0; int start = 0; // the position of the spot all of the way to the left, and the starting point which should be that outer left spot + the safetyBuffer + 1

        for (int i = 0; i < seats; i++) // go through seats from left ---> right
        {
            // if seat is reserved, update left position
             if (seatingLayout[rowIndex][i] == 'R') left = i;
             else continue;
        }
        
        if (left != 0) start = left + safetySpace + 1; //outer left spot + the safetyBuffer + 1

        if (start + reservationSize > seats) return false; //return false if reservations cannot fit in row
        
        else  //concactante result to result string declared in beginning of this program
        {
            String row = rowMap[rowIndex];
            int rowNumber = start + reservationSize;
            output+= row + rowNumber + " " + "\n";
             //update seating chart to replace non-reserved seats with reserved seats
            for (int i = 0; i < reservationSize; i++) seatingLayout[rowIndex][start + i] = 'R';
        }
        return true;
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    public static void main(String[] args) throws IOException 
    {      //intialize the seating array
            seatingLayout = new char[rows][seats];

            for (int i = 0; i < rows; i++) //fill seats as empty intially
            {
                for (int j = 0; j < seats; j++) seatingLayout[i][j] = '_';
            }    

        FileWriter fileWriter = new FileWriter("output.txt");
        File file = new File(args[0]);
        Scanner scanner = new Scanner(file);
        while (scanner.hasNextLine()) parseLine(scanner.nextLine());
        scanner.close();

        //print seats
        System.out.println("\n");
        for (int i =0; i < seatingLayout.length; i++)
        {    //row
             System.out.print(rowMap[i] + "  ");
            for (int j = 0; j < seatingLayout[i].length; j++)
            {   //seat
                System.out.print(seatingLayout[i][j] + " ");
            }
        System.out.println(); 
        }
        
        System.out.println("\n");
        fileWriter.write(output);
        fileWriter.close();
    }
}